import { test, expect } from '@playwright/test';
import { sleep, visualDiff } from './helpers';
import { meta, log, testData } from '../../dist/index.js';

test.describe('Visual', () => {
  test('homepage header matches baseline', { tag: ['@visual'] }, async () => {
    meta({ priority: 'P1', severity: 'major', owner: 'amit', feature: 'home', story: 'UI-77' });
    await test.step('open homepage', async () => { await sleep(150); });
    await test.step('compare header snapshot', async () => {
      await visualDiff('homepage-header');
      expect(1, 'Screenshot comparison failed: 1842 pixels (ratio 0.03) differ').toBe(0);
    });
  });
  test('product card matches baseline', { tag: ['@visual'] }, async () => {
    meta({ priority: 'P2', severity: 'minor', owner: 'amit', feature: 'catalog', story: 'UI-78' });
    await test.step('compare card snapshot', async () => { await sleep(120); });
  });
});
