import { test, expect } from '@playwright/test';
import { shot, sleep, flakyOnce, video, trace } from './helpers';
import { meta, log, testData } from '../../dist/index.js';

test.describe('Checkout', () => {
  test('adds item to cart and updates total', { tag: ['@smoke', '@cart'] }, async () => {
    meta({ priority: 'P0', severity: 'blocker', owner: 'rahul', feature: 'cart', epic: 'EPIC-18', story: 'SHOP-201' });
    await test.step('add "Trail Runner" to cart', async () => { await sleep(140); });
    await test.step('verify cart badge shows 1', async () => { await sleep(60); await shot('cart-badge'); });
  });
  test('applies a valid coupon', { tag: ['@cart', '@promo'] }, async () => {
    meta({ priority: 'P1', severity: 'major', owner: 'rahul', feature: 'promo', epic: 'EPIC-18', story: 'SHOP-210' });
    await test.step('open coupon field', async () => { await sleep(90); });
    await test.step('apply SAVE10', async () => { await sleep(300); });
    await test.step('verify discount line', async () => {
      const total = 89.10; await shot('coupon-applied');
      expect(total).toBeCloseTo(89.10, 2);
    });
  });
  test('stacks two coupons', { tag: ['@promo'] }, async () => {
    meta({ priority: 'P2', severity: 'major', owner: 'rahul', feature: 'promo', epic: 'EPIC-18', story: 'SHOP-231' });
    test.info().annotations.push({ type: 'issue', description: 'PROMO-118' });
    await testData([
      { code: 'SAVE10', type: 'percent', value: 10, stackable: true },
      { code: 'FREESHIP', type: 'shipping', value: 5, stackable: true },
    ], 'Coupons under test');
    await log('cart total before coupons: $99.00');
    await test.step('apply SAVE10', async () => { await sleep(120); });
    await test.step('apply FREESHIP', async () => { await sleep(120); await log('ERROR: order summary still shows one discount line'); await shot('after-second-coupon', 'bad'); });
    await test.step('verify both discounts applied', async () => {
      const lines = ['SAVE10 -$9.90'];
      expect(lines, 'second coupon should appear in order summary').toContain('FREESHIP -$5.00');
    });
  });
  test('completes purchase with saved card', { tag: ['@smoke', '@payment'] }, async ({ }, testInfo) => {
    meta({ priority: 'P0', severity: 'blocker', owner: 'naveen', feature: 'payment', epic: 'EPIC-18', story: 'SHOP-250' });
    await test.step('select saved Visa ending 4417', async () => { await sleep(110); });
    await test.step('place order', async () => {
      await sleep(400);
      if (testInfo.project.name === 'webkit-mobile' && flakyOnce('purchase')) {
        await shot('order-spinner', 'bad'); await video(); await trace();
        throw new Error('Timed out waiting for order confirmation: spinner still visible after 30000ms\n  locator: getByRole("heading", { name: "Order confirmed" })');
      }
      await shot('order-confirmed');
    });
    await test.step('verify confirmation number', async () => { await sleep(50); });
  });
  test('shows out-of-stock message', { tag: ['@cart'] }, async () => {
    meta({ priority: 'P2', severity: 'minor', owner: 'priya', feature: 'cart', epic: 'EPIC-18', story: 'SHOP-260' });
    await test.step('open discontinued product', async () => { await sleep(100); });
    await test.step('verify message', async () => { await sleep(40); });
  });
  test('guest checkout requires email', { tag: ['@checkout'] }, async () => {
    meta({ priority: 'P1', severity: 'critical', owner: 'priya', feature: 'checkout', epic: 'EPIC-18', story: 'SHOP-271' });
    await test.step('continue as guest', async () => { await sleep(70); });
    await test.step('submit without email', async () => { await sleep(90); });
    await test.step('verify validation', async () => {
      await shot('guest-validation', 'bad'); await video();
      expect('Email is required').toBe('Please enter your email');
    });
  });
});
