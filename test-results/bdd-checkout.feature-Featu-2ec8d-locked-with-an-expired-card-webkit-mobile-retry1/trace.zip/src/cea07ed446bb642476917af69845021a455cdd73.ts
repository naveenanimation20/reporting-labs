import { test } from '@playwright/test';
import * as zlib from 'zlib';
import * as fs from 'fs';
import * as os from 'os';
import * as path from 'path';

// Tiny PNG generator so the demo has real screenshots without a browser.
export function png(w: number, h: number, rgb: [number, number, number], accent: [number, number, number]) {
  const rows: Buffer[] = [];
  for (let y = 0; y < h; y++) {
    const row = Buffer.alloc(1 + w * 3); row[0] = 0;
    for (let x = 0; x < w; x++) {
      const header = y < h * 0.12, card = x > w*0.1 && x < w*0.9 && y > h*0.25 && y < h*0.8;
      const c = header ? accent : card ? [255,255,255] as any : rgb;
      row.set(c, 1 + x * 3);
    }
    rows.push(row);
  }
  const crc = (buf: Buffer) => { let c = ~0; for (const b of buf) { c ^= b; for (let k = 0; k < 8; k++) c = c & 1 ? (c >>> 1) ^ 0xEDB88320 : c >>> 1; } return (~c) >>> 0; };
  const chunk = (t: string, d: Buffer) => { const len = Buffer.alloc(4); len.writeUInt32BE(d.length); const td = Buffer.concat([Buffer.from(t), d]); const c = Buffer.alloc(4); c.writeUInt32BE(crc(td)); return Buffer.concat([len, td, c]); };
  const ihdr = Buffer.alloc(13); ihdr.writeUInt32BE(w, 0); ihdr.writeUInt32BE(h, 4); ihdr[8] = 8; ihdr[9] = 2;
  return Buffer.concat([Buffer.from([137,80,78,71,13,10,26,10]), chunk('IHDR', ihdr), chunk('IDAT', zlib.deflateSync(Buffer.concat(rows))), chunk('IEND', Buffer.alloc(0))]);
}
export async function shot(name: string, tone: 'ok' | 'bad' = 'ok') {
  const body = png(320, 200, tone === 'ok' ? [244,246,243] : [251,230,233], [47,91,234]);
  await test.info().attach(name, { body, contentType: 'image/png' });
}
export const sleep = (ms: number) => new Promise(r => setTimeout(r, ms));
export function flakyOnce(key: string) {
  const f = path.join(os.tmpdir(), 'rl-flaky-' + key);
  if (fs.existsSync(f)) { fs.unlinkSync(f); return false; }
  fs.writeFileSync(f, '1'); return true;
}

export async function video(name = 'video') {
  await test.info().attach(name, { path: path.join(__dirname, '..', 'fixtures', 'order-flow.webm'), contentType: 'video/webm' });
}
export async function trace() {
  await test.info().attach('trace', { path: path.join(__dirname, '..', 'fixtures', 'trace.zip'), contentType: 'application/zip' });
}
export async function visualDiff(name: string) {
  const exp = png(320, 200, [244,246,243], [47,91,234]);
  const act = png(320, 200, [244,246,243], [214,69,91]);
  const diff = png(320, 200, [255,255,255], [255,0,255]);
  await test.info().attach(name + '-expected.png', { body: exp, contentType: 'image/png' });
  await test.info().attach(name + '-actual.png', { body: act, contentType: 'image/png' });
  await test.info().attach(name + '-diff.png', { body: diff, contentType: 'image/png' });
}
