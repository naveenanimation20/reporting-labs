import { test, expect } from '@playwright/test';
import { sleep, shot } from '../helpers';
import { meta } from '../../../dist/index.js';

test.describe('Feature: Guest checkout', () => {
  test('Scenario: Guest can buy with a card', { tag: ['@bdd', '@smoke'] }, async () => {
    meta({ priority: 'P0', severity: 'blocker', owner: 'rahul', feature: 'checkout', epic: 'EPIC-18', story: 'SHOP-280' });
    await test.step('Given a guest with 1 item in the cart', async () => { await sleep(90); });
    await test.step('When they check out with a valid card', async () => { await sleep(260); });
    await test.step('And they confirm the order', async () => { await sleep(120); await shot('confirmation'); });
    await test.step('Then they see an order confirmation number', async () => { await sleep(40); });
  });
  test('Scenario: Guest is blocked with an expired card', { tag: ['@bdd', '@negative'] }, async () => {
    meta({ priority: 'P1', severity: 'critical', owner: 'rahul', feature: 'checkout', epic: 'EPIC-18', story: 'SHOP-281' });
    await test.step('Given a guest with 1 item in the cart', async () => { await sleep(80); });
    await test.step('When they check out with an expired card', async () => { await sleep(210); });
    await test.step('Then they see "Card expired" and stay on the payment page', async () => {
      await shot('expired-card', 'bad');
      expect('Payment failed', 'expected specific expiry message').toBe('Card expired');
    });
  });
});
