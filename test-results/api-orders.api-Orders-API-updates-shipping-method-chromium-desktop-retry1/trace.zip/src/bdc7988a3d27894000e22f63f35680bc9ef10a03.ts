import { test, expect } from '@playwright/test';
import { sleep } from '../helpers';
import { meta, api, log } from '../../../dist/index.js';

const H = { 'Content-Type': 'application/json', Authorization: 'Bearer eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJuYXZlZW4ifQ.k9Xz1r2vQ8yT3aBcDeFgHiJkLmNoPqRsTuVwXyZ0123' };

test.describe('Orders API', () => {
  test('creates an order', { tag: ['@api', '@smoke'] }, async () => {
    meta({ priority: 'P0', severity: 'blocker', owner: 'naveen', feature: 'orders-api', epic: 'EPIC-18', story: 'API-301' });
    await test.step('POST /orders', async () => {
      await sleep(140);
      await api({ method: 'POST', url: 'https://api.shoplite.example.com/v1/orders', status: 201, duration: 138,
        requestHeaders: H, requestBody: { items: [{ sku: 'TR-42', qty: 1 }], paymentToken: 'tok_live_9f8e7d6c5b4a', shipping: 'standard' },
        responseHeaders: { 'content-type': 'application/json', 'x-request-id': 'req_8f2a' }, responseBody: { id: 'ord_10422', status: 'created', total: 89.1 } });
      await log('order created: ord_10422');
    });
    await test.step('GET /orders/ord_10422', async () => {
      await sleep(60);
      await api({ method: 'GET', url: 'https://api.shoplite.example.com/v1/orders/ord_10422', status: 200, duration: 52, requestHeaders: H,
        responseHeaders: { 'content-type': 'application/json' }, responseBody: { id: 'ord_10422', status: 'created', items: 1, total: 89.1 } });
      expect(200).toBe(200);
    });
  });
  test('rejects order without items', { tag: ['@api', '@negative'] }, async () => {
    meta({ priority: 'P1', severity: 'major', owner: 'naveen', feature: 'orders-api', epic: 'EPIC-18', story: 'API-302' });
    await sleep(90);
    await api({ method: 'POST', url: 'https://api.shoplite.example.com/v1/orders', status: 400, duration: 41, requestHeaders: H, requestBody: { items: [] },
      responseBody: { error: 'validation_error', message: 'items must not be empty' } });
  });
  test('updates shipping method', { tag: ['@api'] }, async () => {
    meta({ priority: 'P2', severity: 'major', owner: 'priya', feature: 'orders-api', epic: 'EPIC-18', story: 'API-305' });
    await sleep(110);
    await api({ method: 'PATCH', url: 'https://api.shoplite.example.com/v1/orders/ord_10422', status: 500, duration: 2210, requestHeaders: H, requestBody: { shipping: 'express' },
      responseHeaders: { 'content-type': 'application/json', 'x-request-id': 'req_c11d' }, responseBody: { error: 'internal', message: 'shipping service timeout', requestId: 'req_c11d' } });
    await log('ERROR: PATCH returned 500 (shipping service timeout)');
    expect(500, 'expected 200 from PATCH /orders').toBe(200);
  });
  test('deletes a draft order', { tag: ['@api'] }, async () => {
    meta({ priority: 'P2', severity: 'minor', owner: 'priya', feature: 'orders-api', epic: 'EPIC-18', story: 'API-306' });
    await sleep(70);
    await api({ method: 'DELETE', url: 'https://api.shoplite.example.com/v1/orders/ord_draft_1', status: 204, duration: 33, requestHeaders: H });
  });
});
